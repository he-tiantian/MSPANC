function [Y,F,P] = Loadgraphdata(path,numView)

path = strcat('.\', path,'\');
info= load(strcat(path, 'statistics'));
n = info(1,1);
%m = infor(2:size(info,1),1);

edgelist=load(strcat(path,'edgelist'));
edgelist=edgelist+1;
Y = sparse(cat(1,edgelist(:,1),edgelist(:,2)),cat(1,edgelist(:,2),edgelist(:,1)),ones(size(cat(1,edgelist(:,1),edgelist(:,2)),1),1),n,n);

if (numView==1)
    similaritylist=load(strcat(path,'vertex2aid'));
    similaritylist(:,1)=similaritylist(:,1)+1;
    similaritylist(:,2)=similaritylist(:,2)+1;
    m = max(similaritylist(:,2));
    F{1} = sparse(similaritylist(:,2),similaritylist(:,1),ones(size(similaritylist,1),1),m, n);
else
    for i=1:numView
        similaritylist=load(strcat(path,'vertex2aid_',num2str(i)));
        similaritylist(:,1)=similaritylist(:,1)+1;
        similaritylist(:,2)=similaritylist(:,2)+1;
        m = max(similaritylist(:,2));
        F{i} = sparse(similaritylist(:,2),similaritylist(:,1),ones(size(similaritylist,1),1),m, n);
		
		%TF = bsxfun(@rdivide,F{i},sum(F{i},1));
		
		
    end
end
% feature propagation
P = ComputeFD(F,Y);
%di = sum(P,1);
%B = di'*di;
%B = B./sum(sum(P));

% structural proximaty
Y = ComputeSP(Y);
end

%% Compute contextual correlation between pairwise features in each feature view
function [X] = ComputeCC(F)

%m = size(F,1);
di = sum(F,2)+1e-25;
d = sum(sum(F));
FF = F*F';
%X = bsxfun(@max,bsxfun(@minus,log(bsxfun(@rdivide, d*FF, di*di')),log(1)),0);
X = max(log(bsxfun(@rdivide, d*FF, di*di')),0);
X=sparse(X);

X(X<log(2))=0;
FF(X==0)=0;
X = sparse(X);
FF = sparse(FF);
X = (-1)*bsxfun(@rdivide,X,log(FF/d));

clear FF;
clear di;
clear d;

end


%% Structural proximaty between pairwise vertices
function [S] = ComputeSP(Y)

e = 1e-25;
SY = sum(Y,2)+e;
JY = Y'*Y+Y;

S = 0.5*(JY./(SY*SY'));
S = S.*(bsxfun(@plus,repmat(SY,1,size(Y,1)),SY'));
S(Y==0) = 0;

clear SY; clear JY; clear e;

end

%% Total feature diffusion between pairwise vertices
function [SA] = ComputeFD(F,Y)
% transition matrix
T = bsxfun(@rdivide,Y,sum(Y,1));
T(isnan(T))=0;
alpha = 0.5;
beta = 1;
N = size(Y,1);
R = diag(beta)*pinv(eye(N)-alpha*T);
R(R<0) = 0;


e = 1e-25;
numView = size(F,2);
SA = zeros(size(F{1},2),size(F{1},2));
for i = 1:numView
    FR = F{i}*R;
    S = (FR'*FR);
    sf = sum(FR,1);
    S = S./sqrt(sf'*sf);
    S(isnan(S))=0;
    
    %SF = sum(F{i},1)+e;
    %JF = F{i}'*F{i};
    %S = 0.5*(JF./(SF'*SF));
    %S = S.*(bsxfun(@plus,repmat(SF,size(Y,1),1),SF'));
    S(Y==0) = 0;
    %S = S./((sum(F{i},1)+e)'*sum(F{i},1)+e);
    %SA = SA + S;
    SA{i} = S;
	%clear SF; clear JF;
end
%SA = SA./numView;
end