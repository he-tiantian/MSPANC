function [cluster_number] = MSPANC(K,Max_Iter,alpha,beta,interval,path,numView)
%Multi-source propagation aware network clustering

%% Loading graph data
fprintf('Loading network data...\n');

[Y,F,P] = Loadgraphdata(path,numView);

fullrandom = 0;

N = size(Y,1);
Para.Y = Y;
Para.F = F;
Para.P = P;
% weighted sum of feature and structural propagations

Para.V = rand(N,K);

if(fullrandom==1)
    for i = 1 : numView
        U{i} = rand(size(F{i},1),K);
    end
    Para.U = U;
end


Para.K = K;
Para.Max_Iter = Max_Iter;
Para.alpha = alpha;
Para.beta = beta;
lambda = 1;
Para.lambda = lambda;

Para.interval = interval;
Mini_Gap = 1e-5*interval;
Para.Mini_Gap = Mini_Gap;

%% Model optimization
[Result] = Model_Optimization(Para);

fprintf('Model Optimization is done, writing info on latent factors...\n');


%% Output learned latent spaces and log data
%if(Objtype==1)
    %path = strcat('.\',path,'\','Reg\');
%else
    path = strcat('.\',path,'\');
%end
%mkdir(path);
prefix=strcat('K=',num2str(K));

dlmwrite(strcat(path,prefix,'_V'),Result.V);
dlmwrite(strcat(path,prefix,'_H'),Result.H);
%dlmwrite(strcat(path,prefix,'_C'),Result.C);
for i = 1:numView
dlmwrite(strcat(path,prefix,'_U_',num2str(i)),Result.U{i});
%dlmwrite(strcat(path,prefix,'_B'),Result.B);
end


fid = fopen(strcat(path,prefix,'.log'), 'w');
fprintf(fid, 'Parameters setting:\n');
fprintf(fid, 'K = %s\tAlpha=%s\tbeta = %s\tlambda = %s\tMini_Gap = %s\tMax_Iter = %s\n',num2str(K),num2str(alpha),num2str(beta),num2str(lambda),num2str(Mini_Gap),num2str(Max_Iter));
fprintf(fid, 'The number of iterations: %s\n', num2str(Result.loop));
fprintf(fid, 'Optimization Time: %s\n', num2str(Result.time));
fprintf(fid, 'Time consumption per iteration: %s\n', num2str(Result.time/Result.loop));
fprintf(fid, 'Objective values:\n');

for i=1:size(Result.Objective,2)
    fprintf(fid, '%s\t', num2str(Result.Objective(1,i)));
end
fclose(fid);

%% Extract network clusters
fprintf('Identifying clusters...\n');

cluster_number = Identify_Cluster_Base(Result.V,path);

fprintf('Job Done!\n');

end
