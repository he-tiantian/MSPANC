function [Result] = Model_Optimization(Para)

Result =  Optimization_Fact(Para);

end


%% Matrix factorization based learning in both structure and feature spaces
function [Result] = Optimization_Fact(Para)
F = Para.F;
numView = size(F,2);
%X = Para.X;
Y = Para.Y;

%content propagation
P = Para.P;

N = size(Y,1);
K = Para.K;
Max_Iter = Para.Max_Iter;
Mini_Gap = Para.Mini_Gap;
alpha = Para.alpha;
lambda = Para.lambda;
beta = Para.beta;
interval = Para.interval;

if(isfield(Para,'V'))
    V = Para.V;
else
    V = rand(N,K);
end

count = 0;
e = 1e-25;

vec_e = sqrt(lambda)*ones(1,size(V,2));

% Generating U
if(isfield(Para,'U'))
    U = Para.U;
    for i = 1:numView    
        vec_zero = zeros(size(F{i},1),1);
        Fnew{i} = [F{i} vec_zero];
    end
else
    VV = V'*V;
    for i = 1:numView
        vec_zero = zeros(size(F{i},1),1);
        Fnew{i} = [F{i} vec_zero];
        FV = F{i}*V;
        U{i} = max(FV/VV,0);
        clear FV; 
    end
    clear VV;
end
VV = V'*V;
PV = P*V;
H = max(PV/VV,0);

clear Para; clear VV;

fprintf('Model Optimization begins...\n');

tic;
for loop = 1:Max_Iter
    
    %update U
    Vnew = [V;vec_e];
    VV = Vnew'*Vnew;
    SFU = zeros(N,K);
    SVUU = zeros(N,K);
    for i = 1:numView
        
        FV = Fnew{i}*Vnew;
        UVV = U{i}*VV;
        U{i}= U{i}.*(FV./max(UVV,e));
        
        SFU = SFU + F{i}'*U{i};
        UU = U{i}'*U{i};
        SVUU = SVUU + V*UU;
        
    end
    
    VV = V'*V;
    %update H
    HVV = H*VV;
    PV = P*V;
    H = H.*(PV./max(HVV,e));
    
    
    %update V
    a = 2*alpha*V*VV;
    
    HH = H'*H;
    b = SVUU + V + beta*V*HH;
    
    YV = 2*alpha*Y*V;
    c = YV + SFU + beta*P*H;
    
    delta = sqrt(b.^2 + 4*a.*c);
    V = V.*sqrt(max(delta-b,0)./max(2*a,e));
    
    if(loop==1)
       count = count + 1;
       Objective(count) = Compute_Obj_Fact(Y,F,P,V,U,H,alpha,beta,lambda);
       fprintf('The value of objective function after iteration %d is %f.\n', loop, Objective(count));
    end
    
    if(mod(loop,interval)==0&&loop~=Max_Iter&&loop>1)
       count = count + 1;
       Objective(count) = Compute_Obj_Fact(Y,F,P,V,U,H,alpha,beta,lambda);
       if(abs(Objective(1,count)-Objective(1,count-1))<Mini_Gap)
           fprintf('The improvement of objective value after iteration %d is less than Minimum Gap %f, the algorithm is terminated.\n', loop, Mini_Gap);
           Objective = Objective(1,1:count);
           break;
       else
           fprintf('The value of objective function after iteration %d is %f.\n', loop, Objective(count));
       end
    end
    if(loop==Max_Iter)
        count = count + 1;
        Objective(count) = Compute_Obj_Fact(Y,F,P,V,U,H,alpha,beta,lambda);
        fprintf('The value of objective function after %d iteration is %f.\n', Max_Iter, Objective(count));
    end
    
end
time = toc;

Result.V = V;
Result.U = U;
Result.H = H;
Result.time = time;
Result.loop = loop;
Result.Objective = Objective;


end
%% Objective function
function [Obj] = Compute_Obj_Fact(Y,F,P,V,U,H,alpha,beta,lambda)
Obj = 0;
numView = size(F,2);

VV = V*V';
Obj = Obj + sum(sum(VV.^2));
DelY = bsxfun(@minus,Y, VV);
Obj = Obj + alpha*sum(sum(DelY.^2));
clear Y;
clear VV;

HV = H*V';
DelP = P - HV;
Obj = Obj + beta*sum(sum(DelP.^2));

for i=1:numView
    UV = U{i}*V';
    DelF = bsxfun(@minus, F{i}, UV);
    clear F{i}
    clear UV;
    Obj = Obj + sum(sum(DelF.^2));
    
	Obj = Obj + lambda*sum(sum(U{i},2).^2);
end

end
