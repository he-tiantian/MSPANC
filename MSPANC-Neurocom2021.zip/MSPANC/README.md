This repository contains the Matlab implementation of a network clustering model, dubbed Multi-source propagation aware network clustering (MSPANC). If you are interested in using this model in your research works, please cite:

@article{he2021multi,
  title={Multi-source propagation aware network clustering☆},
  author={He, Tiantian and Ong, Yew-Soon and Hu, Pengwei},
  journal={Neurocomputing},
  volume={453},
  pages={119--130},
  year={2021},
  publisher={Elsevier}
}

Notice: The source code is permitted to use only for research and non-commercial activities. If you have any question, please feel free to contact us via tiantian.he@outlook.com.
